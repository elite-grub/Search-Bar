import SearchBar from './components/App.jsx'

window.SearchBar = SearchBar;